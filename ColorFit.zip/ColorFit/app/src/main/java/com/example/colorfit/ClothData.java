package com.example.colorfit;

import java.util.Locale;

public class ClothData {
    private String goods_num;
    private String goods_code;
    private String goods_image;
    private String goods_name;
    private String goods_price;

    public String getGoods_num() {
        return goods_num;
    }
    public void setGoods_num(String goods_num) {
        this.goods_num = goods_num;
    }

    public String getGoods_code() {
        return goods_code;
    }

    public void setGoods_code(String goods_code) {
        this.goods_code = goods_code;
    }

    public String getGoods_image() {
        return goods_image;
    }
    public void setGoods_image(String goods_image) {
        this.goods_image = goods_image;
    }

    public String getGoods_name() {
        return goods_name;
    }
    public void setGoods_name(String goods_name) {
        this.goods_name = goods_name;
    }

    public String getGoods_price() {
        return goods_price;
    }
    public void setGoods_price(String goods_price) {
        this.goods_price = goods_price;
    }


}